<template>
    <div>
        <h1>Home</h1>
        <button class="btn btn-outline-primary" @click="logoutUser()">Logout</button>
        
    </div>
</template>
<script setup>
import { auth } from '../Firebase/index.js';
import router from '../router';

const logoutUser = () => {
    auth.signOut().then(() => {
        router.push('/login');
    });
};
</script>