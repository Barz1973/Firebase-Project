<script setup>
import Login from '../components/login.vue'
</script>
<template>
    <main>
        <Login />
    </main>
</template>